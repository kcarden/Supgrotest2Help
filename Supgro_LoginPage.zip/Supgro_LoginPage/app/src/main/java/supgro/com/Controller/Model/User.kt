package supgro.com.Controller.Model

class User {

    private var username: String = ""
    private var image: String = ""
    private var uid: String = ""

    constructor()

    constructor(username: String, image: String, uid: String){
        this.username = username
        this.image = image
        this.uid = image
    }

    fun getUsername(): String{
        return username
    }
    fun setUsername(username: String){
        this.username = username
    }
    //
    fun getImage(): String{
        return  image
    }
    fun setImage(image: String){
        this.image = image
        //
    }
    fun getUid(): String{
        return uid
    }
    fun setUid(uid: String){
        this.uid = uid
    }
    //
}