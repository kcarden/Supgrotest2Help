package supgro.com.Controller.Model

class Groups (val title: String, val image: String){
    override fun toString(): String {
        return title
    }
}