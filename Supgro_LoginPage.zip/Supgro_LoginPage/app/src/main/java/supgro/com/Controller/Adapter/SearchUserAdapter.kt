package supgro.com.Controller.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.android.synthetic.main.search_button_layouts.view.*
import supgro.com.Controller.Model.User
import supgro.com.R

class SearchUserAdapter (var context: Context,
                         var mUser: List<User>,
                         var isFragment: Boolean = false):
                        RecyclerView.Adapter<SearchUserAdapter.Holder>(){


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(context).inflate(R.layout.search_button_layouts, parent, false)
        return Holder(view)

            }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val user = mUser[position]
        holder.username.text = user.getUsername()
        Picasso.get().load(user.getImage()).placeholder(R.drawable.avataphoto).into(holder.profileimage)

    }

    override fun getItemCount(): Int {
         return mUser.size
    }




    inner class Holder(@NonNull itemView: View) : RecyclerView.ViewHolder(itemView) {

        var username: TextView = itemView.findViewById(R.id.username_Search_TxtVw)
        var profileimage: CircleImageView = itemView.findViewById(R.id.search_ImageVw)


    }

}